package DomainLayer.Enum;

import java.util.*;

public enum CustomerOptions {

    MoveToCart(1),
    Buy(2),
    Exit(3);
    private int value;
    private static Map map = new HashMap<>();

    private CustomerOptions(int value) {
        this.value = value;
    }

    static {
        for (CustomerOptions customerOptions : CustomerOptions.values()) {
            map.put(customerOptions.value, customerOptions);
        }
    }

    public static CustomerOptions valueOf(int customerOptions) {
        return (CustomerOptions) map.get(customerOptions);
    }
}
