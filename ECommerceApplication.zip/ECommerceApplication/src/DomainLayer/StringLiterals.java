/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DomainLayer;

/**
 *
 * @author lavanya.bejugam
 */
public class StringLiterals {
    public static String _validPassword = "Your Password must contain atleast one captial letter, atleastone small letter and atleast one number";
    public static String _invalidLoginPassword = "Password does not match ";
    public static String _invalidEmail = "Invalid Email";
    public static String _userChoice = "User Choice :";
    public static String _email = "Enter EmailID :";
    public static String _login = "Enter 1 to Login";
    public static String _register = "Enter 2 to Register";
    public static String _exit = "Enter 3 to Exit";
    public static String _password = "Password : ";
    public static String _moveToCart = "Enter 1 to MoveToCart";
    public static String _buy = "Enter 2 to Buy";
    public static String _firstName = "FirstName: ";
    public static String _lastName = "LastName: ";
    public static String _typeOfReg = "Type of registration";
    public static String _userRoleChoice1 = "Enter 1 to regsiter as a Admin";
    public static String _userRoleChoice2 = "Enter 2 to register as Customer";
    public static String _adminChoice = "Admin Choice";
    public static String _add = "Enter 1 to Add";
    public static String _delete = "Enter 2 to Delete";
    public static String _update = "Enter 3 to Update";
    public static String _Exit = "Enter 4 to Exit";
    public static String _price = "Enter price to update";
    public static String _select = "Select any productname to update its properties";
    public static String _Select = "Select any productname to move to the cart";
    public static String _selectBuy = "Select any productname to purchase";
    public static String _productName = "enter productName";
    public static String _enterPrice = "enter price";
    public static String _description = "enter description";
    public static String _availableStock = "enter avaliableStock";
    public static String _noOfItems = "Enter number of items to be added";
    public static String _customerChoice = "Customer choice";
    public static String _availableProduct = "Available Products :";
                
}
