package BusinessLayer;

import DomainLayer.Models.ProductModel;

public interface IProductBusiness {

    void setProductDetails(ProductModel pobj);

    void deleteItems(String ItemToBeRemoved);

    void updateItem(String productName, float price);

    void display();

    void moveItemToCart(String productName);
}
