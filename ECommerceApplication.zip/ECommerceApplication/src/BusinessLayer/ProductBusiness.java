package BusinessLayer;

import DomainLayer.Models.ProductModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IProductRepo;

public class ProductBusiness implements IProductBusiness {

    IProductRepo _productObj;

    public ProductBusiness() {
        _productObj = FactoryRepo.product();
    }

    @Override
    public void setProductDetails(ProductModel pobj) {
        _productObj.setProductDetails(pobj);
    }

    @Override
    public void deleteItems(String ItemToBeRemoved) {

        _productObj.deleteItems(ItemToBeRemoved);
    }

    @Override
    public void updateItem(String productName, float price) {
        _productObj.updateItem(productName, price);
    }

    @Override
    public void display() {
        _productObj.display();
    }

    @Override
    public void moveItemToCart(String productName) {
        _productObj.moveItemToCart(productName);
    }
}
