package BusinessLayer;

import DomainLayer.Models.RegistrationModel;

public interface IUserBusiness {

    void setUserDetails(RegistrationModel robj);

}
