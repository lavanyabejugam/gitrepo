package RepositoryLayer;

import DomainLayer.Models.LoginModel;
import DomainLayer.Models.RegistrationModel;

class AuthenticationRepo implements IAuthenticateRepo {

    @Override
    public boolean validateLogin(LoginModel loginModel) {

        return DataSource._userList.stream().anyMatch(m -> m.Email.equals(loginModel.getEmail()) && m.Password.equals(loginModel.getPassword()));
    }

    @Override
    public boolean validateEmail(String email) {
        if (!DataSource._userList.stream().anyMatch(m -> m.Email.equals(email))) {
            return true;
        }

        return false;
    }

    @Override
    public boolean isAdmin(LoginModel loginModel) {
        for (RegistrationModel b : DataSource._userList) {

            if ((b.Email).equals(loginModel.getEmail())) {
                return b.IsAdmin;
            }
        }
        return false;
    }
}
