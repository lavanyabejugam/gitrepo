package RepositoryLayer;

import DomainLayer.Models.*;

public class ProductRepo implements IProductRepo {

    @Override
    public void display() {
        DataSource._productList.stream().forEach((b) -> {
            System.out.println(b.getCategory() + "\n" + b.getSubCategory() + "\n" + b.getProductName() + " " + b.getPrice() + " " + b.getDescription() + " " + b.getAvaliableStock());
        });
    }

    @Override
    public void setProductDetails(ProductModel pObj) {
        DataSource._productList.add(pObj);

    }

    @Override
    public void deleteItems(String ItemToBeRemoved) {
        DataSource._productList.stream().forEach((b) -> {
            if ((b.getProductName()).equals(ItemToBeRemoved) && (b.getAvaliableStock() == 1)) {
                DataSource._productList.remove(b);
            } else if ((b.getProductName()).equals(ItemToBeRemoved) && (b.getAvaliableStock() > 1)) {
                b.setAvaliableStock(b.getAvaliableStock() - 1);
            }
        });

    }

    @Override
    public void updateItem(String productName, float price) {
        DataSource._productList.stream().filter((b) -> (b.productName.equals(productName))).forEach((b) -> {
            b.price = price;
        });
    }

    @Override
    public void moveItemToCart(String productName) {
        for (ProductModel b : DataSource._productList) {
            if (b.productName.equals(productName)) {
                DataSource._cartList.add(b);
            }
        }
    }
}
