package RepositoryLayer;

import DomainLayer.Models.ProductModel;

public interface IProductRepo {

    public void setProductDetails(ProductModel pObj);

    public void deleteItems(String ItemToBeRemoved);

    public void updateItem(String productName, float price);

    public void display();

    void moveItemToCart(String productName);
}
