package RepositoryLayer;

import DomainLayer.Models.ProductModel;
import DomainLayer.Models.RegistrationModel;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class DataSource {

    public static List<RegistrationModel> _userList = new ArrayList<>();
    public static List<ProductModel> _productList = new CopyOnWriteArrayList<>();
    public static List<ProductModel> _cartList = new ArrayList<>();
}