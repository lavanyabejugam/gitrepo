package ecommerceapplication;

import BusinessLayer.*;
import DomainLayer.Enum.*;
import DomainLayer.Models.*;
import DomainLayer.StringLiterals;

import java.util.Scanner;

public class Authentication {

    LoginModel _loginmodelObj;
    FactoryBusiness _factoryBusinessObj;
    IAuthenticationBusiness _authObj;
    IUserBusiness _userObj;
    ProductModel _productModelObj;
    AdminOperations _adminOperations;
    CustomerOperations _customerOperations;
    IProductBusiness _productBusiness;

    public Authentication() {

        _loginmodelObj = new LoginModel();
        _factoryBusinessObj = new FactoryBusiness();
        _productModelObj = new ProductModel();
        _adminOperations = new AdminOperations();
        _customerOperations = new CustomerOperations();

    }

    void login() {       
        System.out.print(StringLiterals._email);
        Scanner scanner = new Scanner(System.in);
        _loginmodelObj.Email = scanner.nextLine();
        System.out.print(StringLiterals._password);
        _loginmodelObj.Password = scanner.nextLine();
        _authObj = _factoryBusinessObj.authenticate();
        if (_authObj.validateLogin(_loginmodelObj)) {

            if (_authObj.isAdmin(_loginmodelObj)) {
                AdminOptions option;
                do {
                    System.out.println(StringLiterals._adminChoice);
                    System.out.println(StringLiterals._add);
                    System.out.println(StringLiterals._delete);
                    System.out.println(StringLiterals._update);
                    System.out.println(StringLiterals._Exit);

                    option = AdminOptions.valueOf(scanner.nextInt());
                    scanner.nextLine();
                    switch (option) {
                        case Add:
                            _adminOperations.addItems();
                            break;
                        case Delete:
                            _productBusiness = _factoryBusinessObj.product();
                            _productBusiness.display();
                            System.out.println("Select product to be removed");
                            String ItemToBeRemoved = scanner.nextLine();
                            _adminOperations.removeItems(ItemToBeRemoved);
                            break;
                        case Update:
                            _productBusiness = _factoryBusinessObj.product();
                            _productBusiness.display();
                            System.out.println(StringLiterals._select);
                            String productName = scanner.nextLine();
                            System.out.println(StringLiterals._price);
                            float price = Float.parseFloat(scanner.nextLine());
                            _adminOperations.updateItem(productName, price);
                            break;

                    }
                } while (option != AdminOptions.Exit);

            } else {
                CustomerOptions option;
                do {
                    System.out.println(StringLiterals._customerChoice);
                    System.out.println(StringLiterals._moveToCart);
                    System.out.println(StringLiterals._buy);
                    System.out.println(StringLiterals._exit);
                    option = CustomerOptions.valueOf(scanner.nextInt());
                    scanner.nextLine();
                    switch (option) {
                        case MoveToCart:
                            _productBusiness = _factoryBusinessObj.product();
                            System.out.println(StringLiterals._availableProduct);
                            _productBusiness.display();
                            System.out.println(StringLiterals._Select);
                            String productName = scanner.nextLine();
                            _customerOperations.moveItemToCart(productName);
                            break;
                        case Buy:
                            _productBusiness = _factoryBusinessObj.product();
                            _productBusiness.display();
                            System.out.println(StringLiterals._selectBuy);
                            String productname = scanner.nextLine();
                            System.out.println("Your product will be delivered in 6 days :" + productname);
                            break;
                    }
                } while (option != CustomerOptions.Exit);
            }
        } else {
            System.out.println(StringLiterals._invalidEmail + "or" + StringLiterals._invalidLoginPassword);
        }
    }

    void register() {
        RegistrationModel _registermodelObj = new RegistrationModel();
        Scanner scanner = new Scanner(System.in);
        System.out.print(StringLiterals._firstName);
        _registermodelObj.FirstName = scanner.nextLine();

        System.out.print(StringLiterals._lastName);
        _registermodelObj.LastName = scanner.nextLine();

        System.out.print(StringLiterals._email);
        _registermodelObj.Email = scanner.nextLine();

        System.out.println(StringLiterals._validPassword);
        System.out.print(StringLiterals._password);
        _registermodelObj.Password = scanner.nextLine();

        System.out.println(StringLiterals._typeOfReg);
        System.out.println(StringLiterals._userRoleChoice1);
        System.out.println(StringLiterals._userRoleChoice2);
        int typeOfReg = Integer.parseInt(scanner.nextLine());
        if (typeOfReg == 1) {
            _registermodelObj.IsAdmin = true;
        } else {
            _registermodelObj.IsAdmin = false;
        }
        if (Validations.validate(_registermodelObj)) {
            _userObj = _factoryBusinessObj.user();
            _userObj.setUserDetails(_registermodelObj);
        }
    }
}
